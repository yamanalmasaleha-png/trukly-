-- Hatchable data export
-- project: truckly
-- exported: 2026-09-08T22:56:17+00:00
-- Apply with: gunzip then psql -f, or upload the .gz as-is during import.
-- Platform auth tables (users/sessions/...) are not included.

--
-- PostgreSQL database dump
--

\restrict Bmopyoybvm91hdflXcrifOA1NTkOuDQhg0bliLNOpNa3wyr95SgkHyeMpUGPV8n

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: bookings; Type: TABLE DATA; Schema: app_9226a7b59ea1a8ea; Owner: -
--



--
-- Data for Name: favorites; Type: TABLE DATA; Schema: app_9226a7b59ea1a8ea; Owner: -
--



--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: app_9226a7b59ea1a8ea; Owner: -
--



--
-- Data for Name: owner_profiles; Type: TABLE DATA; Schema: app_9226a7b59ea1a8ea; Owner: -
--



--
-- Data for Name: owner_schedule; Type: TABLE DATA; Schema: app_9226a7b59ea1a8ea; Owner: -
--



--
-- Data for Name: truck_settings; Type: TABLE DATA; Schema: app_9226a7b59ea1a8ea; Owner: -
--



--
-- PostgreSQL database dump complete
--

\unrestrict Bmopyoybvm91hdflXcrifOA1NTkOuDQhg0bliLNOpNa3wyr95SgkHyeMpUGPV8n

